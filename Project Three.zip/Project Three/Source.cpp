#include <fstream>
#include <string>
#include <map>
#include <iostream>

using namespace std;

//Used to load data from file to map
void loadData(map<string, int>& inventoryMap)
{
	ifstream inputFile("CS210_Project_Three_Input_File.txt");

	if (!inputFile)
	{
		cerr << "Error: Can not open input file." << endl;
		exit(1);
	}
	string item;
	int quantity;

	while (inputFile >> item >> quantity)
	{
		inventoryMap[item] += quantity;
	}
	inputFile.close();
}

//List all items with the frequencies
void listItems(const map<string, int>& inventoryMap)
{
	for (const auto& entry : inventoryMap)
	{
		cout << entry.first << " " << entry.second << endl;
	}
}
//Display histogram of frequencies
void showHistogram(const map<string, int>& inventoryMap)
{
	for (const auto& entry : inventoryMap)
	{
		cout << entry.first << " ";
		for (int i = 0; i < entry.second; i++)
		{
			cout << "*";
		}
		cout << endl;
	}
}
//backup data file
void createBackupData(const map<string, int>& inventoryMap)
{
	ofstream outputFile("frequency.dat");

	if (!outputFile)
	{
		cerr << "Error: Can not create data backup file." << endl;
		exit(1);
	}
	for (const auto& entry : inventoryMap)
	{
		outputFile << entry.first << " " << entry.second << endl;
	}
	outputFile.close();
}

int main()
{
	map<string, int> inventoryMap;
	//input file data loaded into a map
	loadData(inventoryMap);

	string findItem;
	int choice;
	do
	{
		cout << "Menu Options:\n";
		cout << "1. Search for an item's frequency\n";
		cout << "2. List all items with their frequency\n";
		cout << "3. Display a histogram of item frequencies\n";
		cout << "4. Create a backup data file and exit\n";
		cout << "Enter your choice (1-4): ";
		cin >> choice;

		switch (choice)
		{
		case 1:
			// Menu Option One: Search for an item's frequency
			cout << "Enter the item you want to search for: ";
			cin >> findItem;
			if (inventoryMap.find(findItem) != inventoryMap.end())
			{
				cout << "Frequency of " << findItem << ": " << inventoryMap[findItem] << endl;
			}
			else
			{
				cout << "Item not found in the records." << endl;
			}
			break;

		case 2:
			// Menu Option Two: List all items with their frequencies
			listItems(inventoryMap);
			break;

		case 3:
			// Menu Option Three: Display a histogram of item frequencies
			showHistogram(inventoryMap);
			break;

		case 4:
			// Menu Option Four: Create a backup data file and exit
			createBackupData(inventoryMap);
			cout << "Backup data file 'frequency.dat' created." << endl;
			cout << "Closing Program. Have a nice day, goodbye!";
			break;

		default:
			cout << "Invalid choice. Please select a valid option (1-4)." << endl;
			break;
		}
	} while (choice != 4);
	return 0;
}
